# shoe_store Template
<p>This is a Shoe-Store eCommerce website template using HTML and CSS and JS. In this e-commerce website template design I created Home page of eCommerce website with banner section, some featured categories images, then some featured products with product price, image and rating.</p><p> I also made all products page, single product page, shopping cart page, Account (login and registration) page for this Ecommerce Website template.</p>
<br><br>
 <h4>Click here to check the website</h4>
<h2>https://uakp98.github.io/shoe_store/</h2>
